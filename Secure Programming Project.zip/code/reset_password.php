<?php
session_start();
include 'database.php';

if(isset($_POST['new_password'])) {
    $new_password = password_hash($_POST['new_password'], PASSWORD_BCRYPT);
    $email = $_SESSION['reset_email'];

    // Update password in the database
    $sql = "UPDATE user SET password_hash = ?, otp = NULL, otp_expiry = NULL WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $new_password, $email);
    $stmt->execute();

    // Unset session variable
    unset($_SESSION['reset_email']);

    echo "Password reset successfully.";
    header("Location: password_reset_success.php");
}
?>

<form method="post" action="reset_password.php">
    <input type="password" name="new_password" placeholder="Enter new password" required>
    <button type="submit">Reset Password</button>
</form>
