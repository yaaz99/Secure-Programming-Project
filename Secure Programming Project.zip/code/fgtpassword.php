<?php
session_start();
$is_invalid = false;

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Load Composer's autoloader
require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Database configuration
    $host = "localhost";
    $dbname = "login_db";
    $username = "root";
    $password = "";

    // Create database connection
    $mysqli = new mysqli($host, $username, $password, $dbname);

    if ($mysqli->connect_errno) {
        die("Connection Error: " . $mysqli->connect_errno);
    }

    // Check if the form is submitted for OTP generation or password reset
    if (isset($_POST['send_otp'])) {
        $email = $_POST['email'];

        // Validate email
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            die("Invalid email address. Please go back to continue.");
        }

        // Check if email exists in the database
        $sql = sprintf("SELECT * FROM user WHERE email = '%s'", $mysqli->real_escape_string($email));
        $result = $mysqli->query($sql);
        $user = $result->fetch_assoc();

        if ($user) {
            // Generate a random 6-digit OTP
            $otp = rand(100000, 999999);
            $otp_expiry = date("Y-m-d H:i:s", strtotime('+10 minutes'));

            // Save OTP and expiry time to the database
            $sql = "UPDATE user SET otp = ?, otp_expiry = ? WHERE email = ?";
            $stmt = $mysqli->prepare($sql);
            if (!$stmt) {
                die("SQL Error: " . $mysqli->error);
            }
            $stmt->bind_param("iss", $otp, $otp_expiry, $email);
            $stmt->execute();

            // Send OTP to user's email
            $mail = new PHPMailer(true);

            try {
                //Server settings
                $mail->isSMTP();
                $mail->Host       = 'smtp.gmail.com'; // Set the SMTP server to send through
                $mail->SMTPAuth   = true;
                $mail->Username   = 'gengcangkui@gmail.com'; // SMTP username
                $mail->Password   = 'nylb qpdh rncg sjco'; // SMTP password
                $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
                $mail->Port       = 587;

                //Recipients
                $mail->setFrom('noreply@yourdomain.com', 'Mailer');
                $mail->addAddress($email);

                // Content
                $mail->isHTML(true);
                $mail->Subject = 'Your Password Reset OTP';
                $mail->Body    = 'Your OTP for password reset is: ' . $otp;

                $mail->send();
                $_SESSION['email'] = $email;
                header("Location: verify_otp.php");
                exit;
            } catch (Exception $e) {
                echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
            }
        } else {
            $is_invalid = true;
        }
    } elseif (isset($_POST['reset_password'])) {
        $email = $_SESSION['email'];
        $otp = $_POST['otp'];
        $new_password = $_POST['new_password'];

        // Retrieve OTP and expiry time from the database
        $sql = "SELECT otp, otp_expiry FROM user WHERE email = ?";
        $stmt = $mysqli->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->bind_result($db_otp, $db_otp_expiry);
        $stmt->fetch();

        if ($db_otp == $otp && strtotime($db_otp_expiry) > time()) {
            // Update password in the database
            $password_hash = password_hash($new_password, PASSWORD_DEFAULT);
            $sql = "UPDATE user SET password_hash = ?, otp = NULL, otp_expiry = NULL WHERE email = ?";
            $stmt = $mysqli->prepare($sql);
            if (!$stmt) {
                die("SQL Error: " . $mysqli->error);
            }
            $stmt->bind_param("ss", $password_hash, $email);

            if ($stmt->execute()) {
                header("Location: password_reset_success.php");
                exit;
            } else {
                die("Error updating password: " . $mysqli->error);
            }
        } else {
            echo "Invalid or expired OTP.";
        }
    }

    // Close database connection
    $mysqli->close();
}
?>

<!DOCTYPE html>
<html>

<head>
    <title>Password Recovery</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles/index.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f2f2f2;
            text-align: center;
        }

        .container {
            max-width: 400px;
            margin: 50px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            color: #333;
            margin-bottom: 20px;
        }

        p {
            color: #ff0000;
            margin-bottom: 20px;
        }

        form {
            text-align: left;
        }

        input[type="email"],
        input[type="password"],
        input[type="text"],
        button {
            width: 100%;
            padding: 12px;
            margin-top: 10px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }

        button {
            background-color: #007bff;
            color: white;
            cursor: pointer;
            font-size: 16px;
            font-weight: bold;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #0056b3;
        }

        .login-link {
            font-size: 14px;
            color: #007bff;
            text-decoration: none;
        }

        .login-link:hover {
            text-decoration: underline;
        }
    </style>
</head>

<body>
    <div class="container">
        <h1>Password Recovery</h1>

        <?php if ($is_invalid) : ?>
            <p>Invalid email address. Please try again.</p>
        <?php endif; ?>

        <!-- Step 1: Send OTP -->
        <form method="post" action="">
            <input type="hidden" name="send_otp" value="1">
            <input autocomplete="off" type="email" placeholder="Email" name="email" id="email" value="<?= htmlspecialchars($_POST["email"] ?? "") ?>">
            <button type="submit">Send OTP</button>
        </form>

        <!-- Step 2: Verify OTP and reset password -->
        <?php if (isset($_SESSION['email'])) : ?>
            <form method="post" action="">
                <input type="hidden" name="reset_password" value="1">
                <input autocomplete="off" type="text" placeholder="Enter OTP" name="otp" id="otp">
                <input autocomplete="off" type="password" placeholder="New Password" name="new_password" id="new_password">
                <button type="submit">Reset Password</button>
            </form>
        <?php endif; ?>
    </div>
</body>

</html>
