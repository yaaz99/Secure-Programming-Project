<?php
session_start();

// Include database connection
$mysqli = require __DIR__ . "/database.php";

// Check if the connection is successful
if ($mysqli instanceof mysqli === false) {
    die('Database connection failed');
}

// Initialize user variable
$user = null;

// If user is logged in, fetch user data
if (isset($_SESSION["user_id"])) {
    $sql = "SELECT * FROM user WHERE id = ?";
    $stmt = $mysqli->prepare($sql);
    if ($stmt) {
        $stmt->bind_param('i', $_SESSION["user_id"]);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();
        $stmt->close();
    } else {
        echo 'Database query error: ' . $mysqli->error;
    }
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $sql = "SELECT * FROM user WHERE email = ?";
    $stmt = $mysqli->prepare($sql);
    if ($stmt) {
        $stmt->bind_param('s', $_POST["email"]);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();
        $stmt->close();

        if ($user) {
            if (password_verify($_POST["password"], $user["password_hash"])) {
                session_start();
                session_regenerate_id();
                $_SESSION["user_id"] = $user["id"];
                header("Location: pizzas.php");
                exit;
            }
        }
        $is_invalid = true;
    } else {
        echo 'Database query error: ' . $mysqli->error;
    }
}

// Check for order attempt without login
$login_required = isset($_GET['login_required']) && $_GET['login_required'] == '1';
?>

<!DOCTYPE html>
<html>
<head>
    <title>Home Page</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles/index.css">
</head>
<body>
    <div class="container">
        <h1>Welcome to Pizza Order</h1>
        <?php if ($login_required): ?>
            <p class="error">You need to log in or sign up first before checking out.</p>
        <?php endif; ?>
        <?php if (isset($user)): ?>
            <p>Hello, <?= htmlspecialchars($user["username"]); ?>. You are now logged in.</p>
            <p><a href="logout.php">Log Out</a></p>
            <p><a href="pizzas.php">View Pizzas</a></p>
        <?php else: ?>
            <form action="index.php" method="POST">
                <input autocomplete="off" type="email" placeholder="Email" name="email" required>
                <br>
                <input autocomplete="off" type="password" placeholder="Password" name="password" required>
                <br>
                <button type="submit" class="primary">Log In</button>
            </form>
            <p><a class="signup-link" href="signup.php"><button class="secondary">Sign Up</button></a></p>
            <p><a class="signup-link" href="pizzas.php">View Pizzas</a></p>
            <p><a class="" href="fgtpassword.php">Forgot Password</a></p>
        <?php endif; ?>
    </div>
</body>
</html>
