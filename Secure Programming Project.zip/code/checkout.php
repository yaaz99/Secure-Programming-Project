<?php
session_start();

// Include database connection
$mysqli = require __DIR__ . "/database.php";

// Fetch pizzas from the database
$sql = "SELECT * FROM pizzas";
$result = $mysqli->query($sql);

if ($result === false) {
    echo "Error: " . $mysqli->error;
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout</title>
    <link rel="stylesheet" href="styles/checkout.css">
    <!-- Font Awesome for icons (you can download and include locally or use CDN) -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>
<body>
    <div class="container">
        <header>
            <h1 class="checkout-heading">Order Checkout</h1>
        </header>
        <main>
            <form action="process_payment.php" method="POST" class="checkout-form">
                <section class="pizza-selection">
                    <h2 class="section-heading">Choose Your Pizza</h2>
                    <div class="pizza-list">
                        <?php while ($row = $result->fetch_assoc()): ?>
                            <div class="pizza-item">
                                <img src="C:\xampp\htdocs\code\code\images\margerita.jpeg<?= htmlspecialchars($row['image_path']) ?>" alt="<?= htmlspecialchars($row['name']) ?>" class="pizza-image">
                                <div class="pizza-details">
                                    <h3><?= htmlspecialchars($row['name']) ?></h3>
                                    <p class="pizza-price">$<?= htmlspecialchars($row['price']) ?></p>
                                    <label>
                                        <input type="radio" name="pizza" value="<?= $row['id'] ?>" required>
                                        <span>Select</span>
                                    </label>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    </div>
                </section>
                <section class="customer-details">
                    <h2 class="section-heading">Enter Your Details</h2>
                    <div class="input-group">
                        <label for="name">Name:</label>
                        <input type="text" id="name" name="name" required>
                    </div>
                    <div class="input-group">
                        <label for="address">Address:</label>
                        <input type="text" id="address" name="address" required>
                    </div>
                    <div class="input-group">
                        <label for="card_number">Card Number:</label>
                        <input type="text" id="card_number" name="card_number" required>
                    </div>
                    <div class="input-group">
                        <label for="expiry_date">Expiry Date:</label>
                        <input type="text" id="expiry_date" name="expiry_date" required>
                    </div>
                    <div class="input-group">
                        <label for="cvv">CVV:</label>
                        <input type="text" id="cvv" name="cvv" required>
                    </div>
                </section>
                <button type="submit" class="pay-button">Pay Now</button>
            </form>
        </main>
    </div>
</body>
</html>
