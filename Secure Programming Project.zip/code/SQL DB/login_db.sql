-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 10, 2024 at 03:49 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `login_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `pizza_id` int(11) NOT NULL,
  `name` text NOT NULL,
  `address` text NOT NULL,
  `card_number` text NOT NULL,
  `expiry_date` text NOT NULL,
  `cvv` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `pizza_id`, `name`, `address`, `card_number`, `expiry_date`, `cvv`) VALUES
(1, 2, 'aGdaekFlNHVWakt4cVhTdjNTVjFLdz09OjqmkJtpL3m7miXxqUrhudVV', 'MFhpVG5oTENHbnJkU2ZFNC9jL20wQT09Ojou6YBa4S++/AioPYn6EPE+', 'UkVNWGI0Vzh0S2k4eENrNU1sTWdzdz09OjoObSAt9tohd8VIGR+OIVBI', 'UGM2UUhmQldvaWR0dmdjNFF6NUJuQT09OjrpF1mE4iGtu4vqPO0bUhHv', 'M09SbkR1L01sWDBsUnMyS2JCbmRMQT09Ojqsi7iLzX/gj/mQjp2eTkhO'),
(2, 2, 'MW4rYUFkNkJOdE12VUUvb0dYeWRYdz09OjoxoBCjuKTtgiz/M69B+5jc', 'NlNvcTFqTVBzTVI4K3k3MlUzUS9wdz09Ojqt9FnNWl+Ut0N+HRPBTXWV', 'OEUwYmdNNGlDWmFyWWxtYTZTQUJVQT09OjpZPKpllgXu9whkg3oW75Hp', 'SlZGeG5CTzErS1NncmxUbVAybWlqdz09Ojq4Jc8RzypCUFrJHcRtO3Or', 'TURQTEU3d0NIRFM0U3FudHEzQ3Fmdz09OjpV7/wvdsqxitilrV7idZ2S'),
(3, 2, 'N3pXNTgyL3k5bFNlbHNuUWhUMVgyUT09Ojqu1BlvABmZ0USf7XVwTFDu', 'NkFtczdEdzNRRXBxaDcwRUNtZy9Kdz09OjrcO50e4caBbRT86fBTvRHo', 'MEFna2lxVlZDNzVNUUgxTlNaSzRJQT09Ojp46su0NLoMe7A20tsO2IQo', 'S0VyNzhpUjdvTFNDZ3B1ek5iNWc2UT09Ojpj6vr/xVqi3QWFvwuAgqN4', 'Mjk2ZU0rYjM0TTY4b3RGSGh6Y0Jndz09OjpmA7VUgGEhMlxM9g79IsTc'),
(4, 2, 'SS9CK2Rwb1hBZXlMYlA3aTkvTjZGUT09OjoPRes7VIpIJLgvuYAA79rG', 'L2FIYnhUT0JtMTYxWWhZZDQ3KzFFQT09OjrpKlElXRZ5XqhtpE1Gg5EK', 'cGhDbGRGVGJTU2VORnRERXFvbFI5dz09OjpPBdfcGmatli7kHlCc59Fo', 'WklZOE96K0Z1UnhTdVdaamc4Vk1UZz09OjrzYW132yhR3iJuu0TANG3/', 'SXNzeENZczZGRkFscjFnc1crSU1HZz09OjpQeLW6UwlHEjDOOmKnBF6v'),
(5, 3, 'K0hSZTB4bXVIN0YrclJpV0owNWFEQT09Ojr9hYt7nPTQZznEnLYcHgnL', 'bmcwNEpPejhqYjZVMTlzQmlVaVhuZz09OjpCk1syVg67dnO3ixbTbph7', 'RGhRdlhPMzh6L0hqZzJUa251WCt6Zz09OjqwlnLeFSuk83vfF1uo7Osv', 'Q21TVWszUjlwU3FSTmlpNlh3SWtlUT09Ojo30q3nQ51nq59e7cdyb2H6', 'SU1WeGVXRXVzQlpBZkR3ZnRVQjMrQT09OjqMiBSd2eN58TWQlGne3Ohy'),
(6, 3, 'V1FhaFpKUml6cU9lK2Y3Wm1SOHR0UT09OjoRc18vi4K9DxSaJ7kUcJ7/', 'QWhqc1hTSC91K0p2b2M0WGV0SnI3dz09Ojrm52rMREovSOe15rs9sacA', 'UDNmT3M2WWxUSmVOVWMzYU9XVm1NQT09OjpVOt1axBd3tx3OVTJoQh1Q', 'LzdQaFBxNWFDWEkvNE9UZ3R5c1kxQT09OjrOya0ggFmc/YXVZHjYikPh', 'RVZUSlZQN3VUenQyR2lQa3FCc0Zjdz09OjrcX7Y1UBwQ8ucwyRso0lfD'),
(7, 1, 'YXdnU09JVlBFWlF1emdOK0hlcVBQZz09OjpF55HIA+mgaBLxhKa9m1Vv', 'MU04ZE1COUtpNkJQN1BpZWdmWkhQZz09OjoNOonVBYjLXcRyxfCmcYZ2', 'SzFYaE9HQTBCQ2wxWjV6MTVIMFhWZz09OjplJe/9sCKFbHCHL9az4AAy', 'VTlhS2hybDkzeWJQcDV2WnVKRHUxZz09OjrnEo+WjZCWRRr+kbV7g8od', 'T2xiZGZxdG16TnpUTXlBWFFoSkNLdz09Ojr/DONBJ18kH5kC99KFzwhY'),
(8, 1, 'TTRKWEJZUlVSWmh3NjYxY3BDQm5mZz09OjojVBryD5wNu2XtVJdNDSGh', 'NktBWWZPU2RvekttRk5sbkJJZ05nZz09OjrH3h+QA2tQKbSdVVWrEXU9', 'OWFHMGJlQnRwWnhrUm50ekRNZlIrdz09OjqOVRLLWaDumTAncg3Kcbgk', 'dmluUnR2QTNVYmJvbE1DOElwOXdyZz09OjqwV+zhKKf4wOEAOUMnuWpc', 'ZW5OUncvVk1BamQ1UExHQnhSYmdSZz09Ojpgnper6ypAmzW5s93yfOC7');

-- --------------------------------------------------------

--
-- Table structure for table `pizzas`
--

CREATE TABLE `pizzas` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `pizzas`
--

INSERT INTO `pizzas` (`id`, `name`, `price`) VALUES
(1, 'Margherita', 10.00),
(2, 'Pepperoni', 12.00),
(3, 'Veggie', 11.00);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(128) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `reset_token` varchar(255) NOT NULL,
  `token_expiration` datetime(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `email`, `password_hash`, `reset_token`, `token_expiration`) VALUES
(0, '', '', '$2y$10$iq.S8psbBDeql8jAccJSTutn1T0Bftb5rFYvP3wFwV.dmO1/cMjs.', '', '0000-00-00 00:00:00.000000'),
(0, '', '', '$2y$10$iq.S8psbBDeql8jAccJSTutn1T0Bftb5rFYvP3wFwV.dmO1/cMjs.', '', '0000-00-00 00:00:00.000000'),
(0, 'abc', 'abc@gmail.com', '$2y$10$iq.S8psbBDeql8jAccJSTutn1T0Bftb5rFYvP3wFwV.dmO1/cMjs.', '', '0000-00-00 00:00:00.000000'),
(0, 'abdul', 'abdul@gmail.com', '$2y$10$iq.S8psbBDeql8jAccJSTutn1T0Bftb5rFYvP3wFwV.dmO1/cMjs.', '', '0000-00-00 00:00:00.000000'),
(0, 'ccc', 'mohdriyaaz.mr@gmail.com', '$2y$10$iq.S8psbBDeql8jAccJSTutn1T0Bftb5rFYvP3wFwV.dmO1/cMjs.', '', '0000-00-00 00:00:00.000000'),
(0, 'abc', 'mohdriyaaz.mr@gmail.com', '$2y$10$iq.S8psbBDeql8jAccJSTutn1T0Bftb5rFYvP3wFwV.dmO1/cMjs.', '', '0000-00-00 00:00:00.000000'),
(0, 'aa', 'mohdriyaaz.mr@gmail.com', '$2y$10$iq.S8psbBDeql8jAccJSTutn1T0Bftb5rFYvP3wFwV.dmO1/cMjs.', '', '0000-00-00 00:00:00.000000'),
(0, 'aa', 'mohdriyaaz.mr@gmail.com', '$2y$10$iq.S8psbBDeql8jAccJSTutn1T0Bftb5rFYvP3wFwV.dmO1/cMjs.', '', '0000-00-00 00:00:00.000000'),
(0, 'abc', 'mohdriyaaz.mr@gmail.com', '$2y$10$iq.S8psbBDeql8jAccJSTutn1T0Bftb5rFYvP3wFwV.dmO1/cMjs.', '', '0000-00-00 00:00:00.000000'),
(0, 'abu123', 'abu123@gmail.com', '$2y$10$iq.S8psbBDeql8jAccJSTutn1T0Bftb5rFYvP3wFwV.dmO1/cMjs.', '', '0000-00-00 00:00:00.000000'),
(0, 'ali', 'ali@gmail.com', '$2y$10$iq.S8psbBDeql8jAccJSTutn1T0Bftb5rFYvP3wFwV.dmO1/cMjs.', '', '0000-00-00 00:00:00.000000'),
(0, 'ali123', 'ali@gmail.com', '$2y$10$iq.S8psbBDeql8jAccJSTutn1T0Bftb5rFYvP3wFwV.dmO1/cMjs.', '', '0000-00-00 00:00:00.000000'),
(0, 'ali', 'ali123@gmail.com', '$2y$10$iq.S8psbBDeql8jAccJSTutn1T0Bftb5rFYvP3wFwV.dmO1/cMjs.', '', '0000-00-00 00:00:00.000000');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pizza_id` (`pizza_id`);

--
-- Indexes for table `pizzas`
--
ALTER TABLE `pizzas`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `pizzas`
--
ALTER TABLE `pizzas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`pizza_id`) REFERENCES `pizzas` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
