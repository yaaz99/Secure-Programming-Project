<?php
session_start();
include 'database.php';

if(isset($_POST['email']) && isset($_POST['otp'])) {
    $email = $_POST['email'];
    $otp = $_POST['otp'];

    // Retrieve OTP and expiry time from the database
    $sql = "SELECT otp, otp_expiry FROM user WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->bind_result($db_otp, $db_otp_expiry);
    $stmt->fetch();

    if($db_otp == $otp && strtotime($db_otp_expiry) > time()) {
        $_SESSION['reset_email'] = $email;
        header("Location: reset_password.php");
    } else {
        echo "Invalid or expired OTP.";
        header("Location: fgtpassword.php");
    }
}
?>

<form method="post" action="verify_otp.php">
    <input type="email" name="email" placeholder="Enter your email" required>
    <input type="text" name="otp" placeholder="Enter OTP" required>
    <button type="submit">Verify OTP</button>
</form>
