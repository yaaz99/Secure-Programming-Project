<?php
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Database configuration
    $host = "localhost";
    $dbname = "login_db";
    $username = "root";
    $password = "";

    // Create database connection
    $mysqli = new mysqli($host, $username, $password, $dbname);

    if ($mysqli->connect_errno) {
        die("Connection Error: " . $mysqli->connect_errno);
    }

    // Validate input
    if (empty($_POST["email"]) || empty($_POST["password"])) {
        die("Email and password are required. Please go back to continue.");
    }

    if ($_POST["password"] !== $_POST["confirm_password"]) {
        die("Password and confirm password must match. Please go back to continue.");
    }

    // Prepare SQL statement
    $sql = "INSERT INTO user (email, password_hash) VALUES (?, ?)";
    $stmt = $mysqli->prepare($sql);

    if (!$stmt) {
        die("SQL Error: " . $mysqli->error);
    }

    // Hash password
    $password_hash = password_hash($_POST["password"], PASSWORD_DEFAULT);

    // Bind parameters and execute query
    $stmt->bind_param("ss", $_POST["email"], $password_hash);
    if ($stmt->execute()) {
        header("Location: signup_success.php");
        exit;
    } else {
        die("Error: " . $mysqli->error);
    }

    // Close statement and connection
    $stmt->close();
    $mysqli->close();
}
?>
