<?php
session_start();
$mysqli = require __DIR__ . "/database.php";

// Fetch all pizzas
$sql = "SELECT * FROM pizzas";
$result = $mysqli->query($sql);

$pizzas = [];
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $pizzas[] = $row;
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Select Pizzas</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles/pizzas.css">
</head>
<body>
    <div class="container">
        <h1>Select Pizzas</h1>
        <table>
            <thead>
                <tr>
                    <th>Pizza</th>
                    <th>Price</th>
                    <th>Image</th>
                    <th>Order</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pizzas as $pizza): ?>
                    <tr>
                        <td><?= htmlspecialchars($pizza['name']) ?></td>
                        <td>$<?= htmlspecialchars($pizza['price']) ?></td>
                        <td><img src="<?= htmlspecialchars($pizza['image_path']) ?>" alt="<?= htmlspecialchars($pizza['name']) ?>" width="100"></td>
                        <td>
                            <?php if (isset($_SESSION["user_id"])): ?>
                                <form action="checkout.php" method="POST">
                                    <input type="hidden" name="pizza_id" value="<?= htmlspecialchars($pizza['id']) ?>">
                                    <button type="submit">Order Now</button>
                                </form>
                            <?php else: ?>
                                <form action="index.php" method="GET">
                                    <input type="hidden" name="login_required" value="1">
                                    <button type="submit">Order Now</button>
                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
