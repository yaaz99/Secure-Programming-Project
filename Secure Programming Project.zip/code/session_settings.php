<?php
// Set session cookie parameters
session_set_cookie_params([
    'lifetime' => 0, // Session cookie, expires when the browser closes // Set your domain or leave as an empty string for the current domain
    'secure' => true, // Only send cookies over HTTPS
    'httponly' => true, // Make cookies accessible only through the HTTP protocol
    'samesite' => 'Strict', // Helps protect against CSRF
]);

// Start the session
session_start();
?>
