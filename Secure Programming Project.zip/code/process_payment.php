<?php
session_start();

// Include database connection
$mysqli = require __DIR__ . "/database.php";

$encryption_key = "secureprogrammin";

// Function to encrypt data
function encrypt_data($data, $encryption_key) {
    $iv = openssl_random_pseudo_bytes(openssl_cipher_iv_length('aes-256-cbc'));
    $encrypted = openssl_encrypt($data, 'aes-256-cbc', $encryption_key, 0, $iv);
    return base64_encode($encrypted . '::' . $iv);
}

// Function to decrypt data
function decrypt_data($data, $encryption_key) {
    list($encrypted_data, $iv) = explode('::', base64_decode($data), 2);
    return openssl_decrypt($encrypted_data, 'aes-256-cbc', $encryption_key, 0, $iv);
}

// Encrypt sensitive information
$name = encrypt_data($_POST['name'], $encryption_key);
$address = encrypt_data($_POST['address'], $encryption_key);
$card_number = encrypt_data($_POST['card_number'], $encryption_key);
$expiry_date = encrypt_data($_POST['expiry_date'], $encryption_key);
$cvv = encrypt_data($_POST['cvv'], $encryption_key);

// Process payment (dummy processing for demonstration)
$pizza_id = $_POST['pizza'];

// Store the encrypted information and pizza ID in the database
$sql = "INSERT INTO orders (pizza_id, name, address, card_number, expiry_date, cvv) VALUES (?, ?, ?, ?, ?, ?)";
$stmt = $mysqli->prepare($sql);
$stmt->bind_param("isssss", $pizza_id, $name, $address, $card_number, $expiry_date, $cvv);

if ($stmt->execute()) {
    echo "Payment successful!";
    
} else {
    echo "Error: " . $stmt->error;
}



$stmt->close();
$mysqli->close();
?>

